export const DATA_TEST_TYPES = [
  {
    key: "native_http",
    label: "Native Android HTTP",
    status: "active",
    description: "Runs BabyDragon native Android DL/UL throughput tests inside the APK.",
  },
  {
    key: "ftp",
    label: "FTP",
    status: "setup",
    description: "FTP DL/UL setup page is wired. Step 1G uses a safe placeholder engine while RF/GPS recording runs.",
  },
  {
    key: "iperf",
    label: "iPerf",
    status: "planned",
    description: "Planned TCP/UDP iPerf workflow with server, port, streams, duration, and interval settings.",
  },
  {
    key: "ookla_app",
    label: "OOKLA App",
    status: "planned",
    description: "Open OOKLA app, upload screenshot, OCR candidate values, then FE confirms final values.",
  },
  {
    key: "fcc_app",
    label: "FCC App",
    status: "planned",
    description: "Open FCC app, import FCC export, truncate by BabyDragon session timestamps, and save grid-named outputs.",
  },
];

export const DATA_DIRECTIONS = [
  { key: "dl_ul", label: "DL + UL" },
  { key: "dl", label: "DL only" },
  { key: "ul", label: "UL only" },
];

export const DATA_TEST_STORAGE_KEYS = {
  nativeHttp: "bd_rf_native_http_setup_v1",
  ftp: "bd_rf_ftp_setup_v1",
  iperf: "bd_rf_iperf_setup_v1",
};

export const NATIVE_HTTP_PRESETS = [
  {
    key: "cloudflare_demo",
    label: "Cloudflare demo",
    hint: "Default BabyDragon HTTP DL/UL preset",
    values: {
      testType: "native_http",
      presetKey: "cloudflare_demo",
      direction: "dl_ul",
      durationSeconds: 10,
      warmupSeconds: 3,
      intervalSeconds: 1,
      iterations: 1,
      waitSeconds: 5,
      downloadUrl: "https://speed.cloudflare.com/__down",
      uploadUrl: "https://speed.cloudflare.com/__up",
    },
  },
  {
    key: "custom",
    label: "Custom HTTP server",
    hint: "Keep fields editable for customer/project URLs",
    values: {
      testType: "native_http",
      presetKey: "custom",
    },
  },
];

export const FTP_PRESETS = [
  {
    key: "rebex_dl_demo",
    label: "Rebex DL demo",
    hint: "Read-only FTP demo for download/list testing",
    values: {
      testType: "ftp",
      presetKey: "rebex_dl_demo",
      direction: "dl",
      durationSeconds: 10,
      warmupSeconds: 3,
      intervalSeconds: 1,
      iterations: 1,
      waitSeconds: 5,
      host: "test.rebex.net",
      port: "21",
      username: "demo",
      password: "password",
      passiveMode: true,
      secure: false,
      downloadRemotePath: "/readme.txt",
      uploadRemotePath: "/",
      uploadFileSizeMb: 10,
      notes: "Rebex public FTP is read-only and speed-limited. Use it for DL setup validation only.",
    },
  },
  {
    key: "dlptest_ul_demo",
    label: "DLPTest UL demo",
    hint: "Public FTP upload demo; password may rotate",
    values: {
      testType: "ftp",
      presetKey: "dlptest_ul_demo",
      direction: "ul",
      durationSeconds: 10,
      warmupSeconds: 3,
      intervalSeconds: 1,
      iterations: 1,
      waitSeconds: 5,
      host: "ftp.dlptest.com",
      port: "21",
      username: "dlpuser",
      password: "rNrKYTX9g7z3RgJRmxWuGHbeu",
      passiveMode: true,
      secure: false,
      downloadRemotePath: "/",
      uploadRemotePath: "/",
      uploadFileSizeMb: 10,
      notes: "DLPTest stores uploaded files temporarily and may rotate password. Verify before field use.",
    },
  },
  {
    key: "custom",
    label: "Custom FTP server",
    hint: "Use customer/project FTP server details",
    values: {
      testType: "ftp",
      presetKey: "custom",
    },
  },
];

export const IPERF_PRESETS = [
  {
    key: "iperf_fr_ping_online",
    label: "Public iPerf demo",
    hint: "ping.online.net, port 5201",
    values: {
      testType: "iperf",
      presetKey: "iperf_fr_ping_online",
      direction: "dl_ul",
      server: "ping.online.net",
      port: "5201",
      protocol: "TCP",
      streams: "1",
      durationSeconds: 10,
      warmupSeconds: 3,
      intervalSeconds: 1,
      iterations: 1,
      waitSeconds: 5,
      reverseMode: true,
      udpBitrateMbps: "10",
      notes: "Public iPerf servers may be busy. For production, use customer-controlled iPerf server.",
    },
  },
  {
    key: "custom",
    label: "Custom iPerf server",
    hint: "Use your own iPerf3 server/IP and port",
    values: {
      testType: "iperf",
      presetKey: "custom",
    },
  },
];

export const DEFAULT_NATIVE_HTTP_SETUP = {
  ...NATIVE_HTTP_PRESETS[0].values,
};

export const DEFAULT_FTP_SETUP = {
  ...FTP_PRESETS[0].values,
};

export const DEFAULT_IPERF_SETUP = {
  ...IPERF_PRESETS[0].values,
};

export const DEFAULT_FCC_IMPORT_SETUP = {
  timestampBufferSeconds: 30,
  keepRawImport: true,
  saveTruncatedByGrid: true,
};

export const DEFAULT_OOKLA_SETUP = {
  ocrAssist: true,
  requireFeConfirmation: true,
  keepScreenshot: true,
};
