import React, { useEffect, useMemo, useRef } from "react";
import {
  DATA_DIRECTIONS,
  DATA_TEST_STORAGE_KEYS,
  DEFAULT_IPERF_SETUP,
  IPERF_PRESETS,
} from "../../config/dataTestConfig";

function cleanIntegerDraft(value, maxDigits = 4) {
  return String(value ?? "")
    .replace(/[^0-9]/g, "")
    .slice(0, maxDigits);
}

function selectOnFocus(event) {
  window.setTimeout(() => event.target.select?.(), 0);
}

function safeReadJson(key) {
  if (typeof window === "undefined" || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function safeWriteJson(key, value) {
  if (typeof window === "undefined" || !window.localStorage) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Local storage can be blocked on some WebViews. Setup still works in memory.
  }
}

function InputBox({ label, unit, value, onChange, disabled, maxDigits = 4 }) {
  return (
    <label>
      <span>{label}</span>
      <input
        disabled={disabled}
        inputMode="numeric"
        value={value ?? ""}
        onFocus={selectOnFocus}
        onChange={(event) => onChange(cleanIntegerDraft(event.target.value, maxDigits))}
      />
      {unit ? <em>{unit}</em> : null}
    </label>
  );
}

export default function IperfTestCard({ setup = DEFAULT_IPERF_SETUP, onChange, disabled = false }) {
  const loadedLastUsedRef = useRef(false);
  const skipFirstSaveRef = useRef(true);
  const current = useMemo(() => ({ ...DEFAULT_IPERF_SETUP, ...(setup || {}) }), [setup]);
  const update = (patch, markCustom = true) => onChange?.({ ...current, ...(markCustom ? { presetKey: "custom" } : {}), ...patch });

  useEffect(() => {
    if (loadedLastUsedRef.current) return;
    loadedLastUsedRef.current = true;
    const saved = safeReadJson(DATA_TEST_STORAGE_KEYS.iperf);
    if (saved && typeof saved === "object") {
      onChange?.({ ...DEFAULT_IPERF_SETUP, ...saved });
    }
  }, [onChange]);

  useEffect(() => {
    if (!loadedLastUsedRef.current) return;
    if (skipFirstSaveRef.current) {
      skipFirstSaveRef.current = false;
      return;
    }
    safeWriteJson(DATA_TEST_STORAGE_KEYS.iperf, current);
  }, [current]);

  function applyPreset(presetKey) {
    const preset = IPERF_PRESETS.find((item) => item.key === presetKey);
    if (!preset) return;
    if (preset.key === "custom") {
      update({ presetKey: "custom" }, false);
      return;
    }
    onChange?.({ ...DEFAULT_IPERF_SETUP, ...preset.values });
  }

  function resetDemo() {
    const demo = IPERF_PRESETS[0]?.values || DEFAULT_IPERF_SETUP;
    onChange?.({ ...DEFAULT_IPERF_SETUP, ...demo });
  }

  const activePreset = IPERF_PRESETS.find((item) => item.key === current.presetKey) || IPERF_PRESETS[0];

  return (
    <section className="bd-rf-test-card bd-rf-test-card-iperf bd-rf-test-card-planned">
      <header>
        <div>
          <b>iPerf Test</b>
          <span>Planned isolated coding page for TCP/UDP iPerf. Step 1G1A adds safe demo presets and last-used setup.</span>
        </div>
        <em>Planned</em>
      </header>

      <div className="bd-rf-preset-row">
        <label>
          <span>Preset</span>
          <select disabled={disabled} value={activePreset.key} onChange={(event) => applyPreset(event.target.value)}>
            {IPERF_PRESETS.map((preset) => (
              <option key={preset.key} value={preset.key}>{preset.label}</option>
            ))}
          </select>
          <em>{activePreset.hint}</em>
        </label>
        <button type="button" disabled={disabled} onClick={resetDemo}>Reset Demo</button>
      </div>

      <label>
        <span>Server host/IP</span>
        <input disabled={disabled} value={current.server || ""} onFocus={selectOnFocus} onChange={(event) => update({ server: event.target.value })} />
      </label>

      <div className="bd-rf-test-card-grid">
        <InputBox label="Port" unit="tcp/udp" value={current.port} onChange={(port) => update({ port })} disabled={disabled} maxDigits={5} />
        <label>
          <span>Protocol</span>
          <select disabled={disabled} value={current.protocol || "TCP"} onChange={(event) => update({ protocol: event.target.value })}>
            <option value="TCP">TCP</option>
            <option value="UDP">UDP</option>
          </select>
          <em>mode</em>
        </label>
        <InputBox label="Streams" unit="parallel" value={current.streams} onChange={(streams) => update({ streams })} disabled={disabled} maxDigits={2} />
        <label>
          <span>Direction</span>
          <select disabled={disabled} value={current.direction || DEFAULT_IPERF_SETUP.direction} onChange={(event) => update({ direction: event.target.value })}>
            {DATA_DIRECTIONS.map((item) => <option key={item.key} value={item.key}>{item.label}</option>)}
          </select>
          <em>mode</em>
        </label>
        <InputBox label="Duration" unit="sec" value={current.durationSeconds} onChange={(durationSeconds) => update({ durationSeconds })} disabled={disabled} maxDigits={3} />
        <InputBox label="Warmup" unit="sec" value={current.warmupSeconds} onChange={(warmupSeconds) => update({ warmupSeconds })} disabled={disabled} maxDigits={2} />
        <InputBox label="Interval" unit="sec" value={current.intervalSeconds} onChange={(intervalSeconds) => update({ intervalSeconds })} disabled={disabled} maxDigits={2} />
        <InputBox label="Iterations" unit="count" value={current.iterations} onChange={(iterations) => update({ iterations })} disabled={disabled} maxDigits={2} />
        <InputBox label="Wait" unit="sec" value={current.waitSeconds} onChange={(waitSeconds) => update({ waitSeconds })} disabled={disabled} maxDigits={3} />
        <InputBox label="UDP bitrate" unit="Mbps" value={current.udpBitrateMbps} onChange={(udpBitrateMbps) => update({ udpBitrateMbps })} disabled={disabled} maxDigits={5} />
      </div>

      <label className="bd-rf-check-row">
        <input disabled={disabled} type="checkbox" checked={Boolean(current.reverseMode)} onChange={(event) => update({ reverseMode: event.target.checked })} />
        <span>Use reverse mode for DL where server supports it</span>
      </label>

      {current.notes ? <p className="bd-rf-mini-note">{current.notes}</p> : null}
    </section>
  );
}
