import React from "react";
import { DEFAULT_NATIVE_HTTP_SETUP, DATA_DIRECTIONS } from "../../config/dataTestConfig";

export default function NativeHttpTestCard({ setup = DEFAULT_NATIVE_HTTP_SETUP, onChange, disabled = false }) {
  const update = (patch) => onChange?.({ ...setup, ...patch });

  return (
    <section className="bd-rf-test-card bd-rf-test-card-native">
      <header>
        <div>
          <b>Native Android HTTP</b>
          <span>Internal BabyDragon DL/UL engine. No external app required.</span>
        </div>
      </header>
      <label>
        <span>Direction</span>
        <select disabled={disabled} value={setup.direction || "dl_ul"} onChange={(event) => update({ direction: event.target.value })}>
          {DATA_DIRECTIONS.map((direction) => (
            <option key={direction.key} value={direction.key}>{direction.label}</option>
          ))}
        </select>
      </label>
      <div className="bd-rf-test-card-grid">
        <label><span>Duration</span><input disabled={disabled} inputMode="numeric" value={setup.durationSeconds ?? 10} onChange={(event) => update({ durationSeconds: event.target.value })} /><em>sec</em></label>
        <label><span>Interval</span><input disabled={disabled} inputMode="numeric" value={setup.intervalSeconds ?? 1} onChange={(event) => update({ intervalSeconds: event.target.value })} /><em>sec</em></label>
        <label><span>Iterations</span><input disabled={disabled} inputMode="numeric" value={setup.iterations ?? 1} onChange={(event) => update({ iterations: event.target.value })} /></label>
        <label><span>Wait</span><input disabled={disabled} inputMode="numeric" value={setup.waitSeconds ?? 5} onChange={(event) => update({ waitSeconds: event.target.value })} /><em>sec</em></label>
      </div>
      <label><span>DL URL</span><input disabled={disabled} value={setup.downloadUrl || ""} onChange={(event) => update({ downloadUrl: event.target.value })} /></label>
      <label><span>UL URL</span><input disabled={disabled} value={setup.uploadUrl || ""} onChange={(event) => update({ uploadUrl: event.target.value })} /></label>
    </section>
  );
}
